# shiny-memory-2605

Team conventions:

- Java naming:

- SQL naming: 

- Using git:

